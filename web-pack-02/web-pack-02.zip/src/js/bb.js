
const Fnstr = (...arg)=>{
    return arg.reduce((p,n)=>p+n);
}
const isAArray = (one,arr)=>{
    return  one;
}
export {Fnstr};
